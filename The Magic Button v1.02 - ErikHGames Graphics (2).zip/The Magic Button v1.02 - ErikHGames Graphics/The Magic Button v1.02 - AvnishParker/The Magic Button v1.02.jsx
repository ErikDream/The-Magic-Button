﻿function expressionPanel(thisObj) {
        var win = (thisObj instanceof Panel) ? thisObj : new Window('palette', 'Expression Script', undefined);
        win.spacing = 6;
        var tabPanel = win.add('tabbedpanel');
        tabPanel.alignChildren = ['fill', 'fill'];
        tabPanel.preferredSize = [350, 300];
}
var myPanel = new Window("palette", "The Magic Button v1.01", undefined, { resizable: true });
myPanel.orientation = "column";

var buttonGroup1 = myPanel.add("group");
buttonGroup1.orientation = "row";

var button1 = buttonGroup1.add("button", undefined, "Bounce");
button1.onClick = function() {
  applyBounceExpression();
};

var button2 = buttonGroup1.add("button", undefined, "LoopOut");
button2.onClick = function() {
  openSubMenu();
};

var buttonGroup2 = myPanel.add("group");
buttonGroup2.orientation = "row";

var button3 = buttonGroup2.add("button", undefined, "Clock");
button3.onClick = function() {
  createClockTextLayer();
};

var button4 = buttonGroup2.add("button", undefined, "Squash");
button4.onClick = function() {
  applySquashExpression();
};

var linkText = myPanel.add("statictext", undefined, "Follow YouTube/ErikHGames Graphics");

myPanel.layout.layout(true);
myPanel.layout.resize();

myPanel.show();

function applyBounceExpression() {
  var comp = app.project.activeItem;
  if (!comp || !(comp instanceof CompItem)) {
    alert("Please open a composition.");
    return;
  }
  
  var selectedProperty = comp.selectedProperties[0];
  if (!selectedProperty) {
    alert("Please select a layer property.");
    return;
  }
  
  // Apply the bounce expression to the selected property
  selectedProperty.expression = 'amp = 0.1;\n' +
    'freq = 2.0;\n' +
    'decay = 5.0;\n' +
    'n = 0;\n' +
    'time_max = 4;\n' +
    'if (numKeys > 0) {\n' +
    '  n = nearestKey(time).index;\n' +
    '  if (key(n).time > time) {\n' +
    '    n--;\n' +
    '  }\n' +
    '}\n' +
    'if (n == 0) {\n' +
    '  t = 0;\n' +
    '} else {\n' +
    '  t = time - key(n).time;\n' +
    '}\n' +
    'if (n > 0 && t < time_max) {\n' +
    '  v = velocityAtTime(key(n).time - thisComp.frameDuration/10);\n' +
    '  value + v * amp * Math.sin(freq * t * 2 * Math.PI) / Math.exp(decay * t);\n' +
    '} else {\n' +
    '  value;\n' +
    '}';
}

function openSubMenu() {
  var subMenuWindow = new Window("palette", "LoopOut", undefined, { resizable: true });

  var subButton1 = subMenuWindow.add("button", undefined, "Ping Pong");
  var subButton2 = subMenuWindow.add("button", undefined, "Continue");
  var subButton3 = subMenuWindow.add("button", undefined, "Cycle");
  var subButton4 = subMenuWindow.add("button", undefined, "Offset");

  subButton1.onClick = function() {
    applyPingPongExpression();
    subMenuWindow.close();
  };

  subButton2.onClick = function() {
    applyContinueExpression();
    subMenuWindow.close();
  };

  subButton3.onClick = function() {
    applyCycleExpression();
    subMenuWindow.close();
  };

  subButton4.onClick = function() {
    applyOffsetExpression();
    subMenuWindow.close();
  };

  subMenuWindow.layout.layout(true);
  subMenuWindow.layout.resize();

  subMenuWindow.show();
}

function createClockTextLayer() {
  var comp = app.project.activeItem;
  if (!comp || !(comp instanceof CompItem)) {
    alert("Please open a composition.");
    return;
  }
  
  var textLayer = comp.layers.addText();
  textLayer.name = "Clock";
  
  var textProperty = textLayer.property("Source Text");
  textProperty.expression = 'var currentTime = time;\n' +
    'var minutes = Math.floor((currentTime % 3600) / 60);\n' +
    'var seconds = Math.floor(currentTime % 60);\n' +
    'var minutesString = minutes.toString().padStart(2, "0");\n' +
    'var secondsString = seconds.toString().padStart(2, "0");\n' +
    'var timeString = minutesString + ":" + secondsString;\n' +
    'timeString;';
}

function applySquashExpression() {
  var comp = app.project.activeItem;
  if (!comp || !(comp instanceof CompItem)) {
    alert("Please open a composition.");
    return;
  }
  
  var selectedProperty = comp.selectedProperties[0];
  if (!selectedProperty) {
    alert("Please select Scale property.");
    return;
  }
  
  selectedProperty.expression = 'maxDev = 50; // max deviation in pixels\n' +
    'spd = 20; // speed of oscillation\n' +
    'decay = 3; // how fast it slows down\n' +
    't = time - inPoint;\n' +
    'x = scale[0] + maxDev * Math.sin(spd * t) / Math.exp(decay * t);\n' +
    'y = scale[0] * scale[1] / x;\n' +
    '[x, y]';
}

function applyPingPongExpression() {
  var comp = app.project.activeItem;
  if (!comp || !(comp instanceof CompItem)) {
    alert("Please open a composition.");
    return;
  }

  var selectedProperty = comp.selectedProperties[0];
  if (!selectedProperty) {
    alert("Please select a property with Keyframes.");
    return;
  }

  selectedProperty.expression = 'loopOut("pingpong")';
}

function applyContinueExpression() {
  var comp = app.project.activeItem;
  if (!comp || !(comp instanceof CompItem)) {
    alert("Please open a composition.");
    return;
  }

  var selectedProperty = comp.selectedProperties[0];
  if (!selectedProperty) {
    alert("Please select a property with Keyframes.");
    return;
  }

  selectedProperty.expression = 'loopOut("continue")';
}

function applyCycleExpression() {
  var comp = app.project.activeItem;
  if (!comp || !(comp instanceof CompItem)) {
    alert("Please open a composition.");
    return;
  }

  var selectedProperty = comp.selectedProperties[0];
  if (!selectedProperty) {
    alert("Please select a property with Keyframes.");
    return;
  }

  selectedProperty.expression = 'loopOut("cycle")';
}

function applyOffsetExpression() {
  var comp = app.project.activeItem;
  if (!comp || !(comp instanceof CompItem)) {
    alert("Please open a composition.");
    return;
  }

  var selectedProperty = comp.selectedProperties[0];
  if (!selectedProperty) {
    alert("Please select a property with Keyframes.");
    return;
  }

  selectedProperty.expression = 'loopOut("offset")';
}
